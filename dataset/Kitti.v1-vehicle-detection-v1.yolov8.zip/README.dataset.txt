# Kitti > vehicle-detection-v1
https://universe.roboflow.com/shreya-co0k0/kitti-buz3u-gwcwq

Provided by a Roboflow user
License: CC BY 4.0

